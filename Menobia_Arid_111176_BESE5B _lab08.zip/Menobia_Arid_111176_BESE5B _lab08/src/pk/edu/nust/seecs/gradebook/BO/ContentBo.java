package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.ContentDao;

import pk.edu.nust.seecs.gradebook.entity.Content;

/**
 * Created by hp 1 on 4/19/2017.
 */
public class ContentBo {

    ContentDao cd = new ContentDao();
    void AddContent (Content clo)
    {
        cd.addContent(clo);
    }
    void UpdateContent (Content clo)
    {
        cd.updateContent(clo);
    }
    void DeleteContent (Content clo)
    {
        cd.deleteContent(clo.getContentId());
    }
}
