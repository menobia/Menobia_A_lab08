package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;

import pk.edu.nust.seecs.gradebook.entity.Content;

/**
 * Created by hp 1 on 4/19/2017.
 */
public class CourseBo {


    /**
     * Created by hp 1 on 4/19/2017.
     */
    public class ContentBo {

        CourseDao cd = new CourseDao();
        void AddContent (Course clo)
        {
            cd.addCourse(clo);
        }
        void UpdateContent (Course clo)
        {
            cd.updateCourse(clo);
        }
        void DeleteContent (Course clo)
        {
            cd.deleteCourse(clo.getCourseid());
        }
    }
}
