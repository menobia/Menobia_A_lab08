package pk.edu.nust.seecs.gradebook.BO;
import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/**
 * Created by hp 1 on 4/19/2017.
 */
public class CloBo {
    Clo c= new  Clo();
    CloDao cd = new CloDao();
    void AddClo (Clo clo)
    {
        cd.addClo(clo);
    }
    void UpdateClo (Clo clo)
    {
        cd.updateClo(clo);
    }
    void DeleteClo (Clo clo)
    {
        cd.deleteClo(clo.getCloId());
    }
}
