package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Grade;

/**
 * Created by hp 1 on 4/19/2017.
 */
public class GradeBo {

}
