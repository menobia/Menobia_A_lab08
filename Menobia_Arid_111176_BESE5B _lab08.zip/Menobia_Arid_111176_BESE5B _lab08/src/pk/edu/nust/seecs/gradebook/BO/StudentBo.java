package pk.edu.nust.seecs.gradebook.BO;

/**
 * Created by hp 1 on 4/19/2017.
 */
public class StudentBo {
}
